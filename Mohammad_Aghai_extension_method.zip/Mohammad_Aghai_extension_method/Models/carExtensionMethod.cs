namespace Mohammad_Aghai_extension_method.Models
{
    public static class carExtensionMethod
    {
        public static string getCarName(this Car car){
            return $"car name is :{car.name}  car color is :{car.color} car Model is {car.model}";
        }
    }
}