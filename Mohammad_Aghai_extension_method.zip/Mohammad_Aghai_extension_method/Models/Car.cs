using System.ComponentModel.DataAnnotations;
using System;
namespace Mohammad_Aghai_extension_method.Models
{
    public class Car
    {
        [Required]
        [Key]
        public int id { get; set; }
          [StringLength(150)]
         public string name { get; set; }
           [StringLength(150)]
          public string color { get; set; }
            [StringLength(150)]
           public string model { get; set; }
    }
}