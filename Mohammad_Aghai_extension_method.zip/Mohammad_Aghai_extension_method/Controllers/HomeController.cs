﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Mohammad_Aghai_extension_method.Models;

namespace Mohammad_Aghai_extension_method.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        var carBMW  =  new Car {name = "BMW2024",color = "red",model = "2024red"};
        string carInfo = carBMW.getCarName();
        @ViewBag.carAbout = carInfo;
        
        return View();
    }

    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
